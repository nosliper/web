package br.quixada.ufc.web.ninjatypr.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

@Entity
public class SpeedTest {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@NotNull
	private String dificulty;
	
	@NotNull
	private Integer keystrokes;
	
	@NotNull
	private Integer speed;
	
	@NotNull
	private float accuracy;
	
	@ManyToOne
	private User user;
	
	public SpeedTest() {
		
	}
	public long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDificulty() {
		return dificulty;
	}
	public void setDificulty(String dificulty) {
		this.dificulty = dificulty;
	}
	public Integer getKeystrokes() {
		return keystrokes;
	}
	public void setKeystrokes(int keystrokes) {
		this.keystrokes = keystrokes;
	}
	public Integer getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public float getAccuracy() {
		return accuracy;
	}
	public void setAccuracy(float accuracy) {
		this.accuracy = accuracy;
	}	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
}
