package br.quixada.ufc.web.ninjatypr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NinjaTyprApplication {

	public static void main(String[] args) {
		SpringApplication.run(NinjaTyprApplication.class, args);
	}
}
