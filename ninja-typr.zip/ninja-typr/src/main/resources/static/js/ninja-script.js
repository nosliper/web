var SAMPLE_TEST = "word one two three four five six seven eight nine ten";

function fillSampleContainer(container, sample) {
	for(var i in sample) {
		var word = document.createElement("span");
		word.setAttribute("class", "sample-word");
		word.innerHTML = sample[i];
		container.appendChild(word);
	}
}
function clearField(field) {
	field.value = "";
}
function onSpace(event) {
	if (32 == event.which) {
		clearField(this);
	}
}
function onTyping(event) {
	//TODO:
}
function fillTestDataForm(form) {
	//TODO:
}
window.addEventListener("load", function() {
	var container = document.getElementById("sample");
	var typingArea =  document.getElementById("typing-area");
	fillSampleContainer(container, SAMPLE_TEST.split(" "));
	typingArea.addEventListener("input", onTyping);
	typingArea.addEventListener("keydown", onSpace);
});